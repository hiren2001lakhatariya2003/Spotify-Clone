//
//  LibraryAlbumsViewController.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 13/08/23.
//

import UIKit

class LibraryAlbumsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
       
    }
    


}
