//
//  AlbumCollectionViewCellViewModel.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 04/08/23.
//

import Foundation
struct AlbumCollectionViewCellViewModel{
    let name: String
    let artistName: String
    
}
