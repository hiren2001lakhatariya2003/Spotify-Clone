//
//  SearchResultDefaultTableViewCellViewModel.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 07/08/23.
//

import Foundation


struct SearchResultDefaultTableViewCellViewModel {
    let title : String
    let imageURL : URL?
}
