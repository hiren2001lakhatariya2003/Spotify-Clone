//
//  RecommendedGenresResponse.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 30/07/23.
//

import Foundation

struct RecommendedGenresResponse : Codable {
    let genres : [String]
}
