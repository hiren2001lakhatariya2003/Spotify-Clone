//
//  LibraryPlaylistsResponse.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 14/08/23.
//

import Foundation

struct LibraryPlaylistsResponse : Codable {
    let items: [Playlist]
}
