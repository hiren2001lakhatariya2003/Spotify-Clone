//
//  RecommendationsResponse.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 30/07/23.
//

import Foundation

struct RecommendationsResponse: Codable {
    let tracks: [AudioTrack]
}


