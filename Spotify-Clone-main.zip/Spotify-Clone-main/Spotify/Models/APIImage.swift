//
//  APIImages.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 17/07/23.
//
import Foundation

struct APIImage: Codable {
    let url: String
}
