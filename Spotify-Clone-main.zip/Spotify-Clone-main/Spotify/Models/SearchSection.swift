//
//  SearchSection.swift
//  Spotify
//
//  Created by Hiren Lakhatariya on 07/08/23.
//

import Foundation

struct SearchSection {
    let title : String
    let results : [SearchReasult]
}
